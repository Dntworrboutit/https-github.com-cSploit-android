package org.csploit.android.net.reference;

/**
 * a simple URL reference
 */
public interface Url {
  String getUrl();
}

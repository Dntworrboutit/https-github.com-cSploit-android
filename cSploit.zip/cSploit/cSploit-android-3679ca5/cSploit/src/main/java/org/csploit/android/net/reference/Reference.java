package org.csploit.android.net.reference;

/**
 * a reference to something
 *
 * TODO: getDrawableResourceId
 */
public interface Reference {
  String getName();
  String getSummary();
}
